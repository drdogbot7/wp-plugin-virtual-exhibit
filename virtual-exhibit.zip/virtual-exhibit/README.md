# Virtual Exhibit Plugin

## Description

The Virtual Exhibit plugin allows users to create and manage virtual exhibits on their WordPress site. It provides an easy-to-use interface for adding exhibits, customizing their appearance, and displaying them on the frontend.

## License

This plugin is licensed under the GPL v2 or later. See the LICENSE file for more details.
